Please deploy to the following path. The path should be write protected for the user. admrawe should have access. Many thanks Ralf 
C:\ProgramData\Climeworks_Solidworks